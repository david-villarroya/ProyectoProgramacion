#ifndef MEMORY_MANAGER_H
#define MEMORY_MANAGER_H

typedef struct {
    char *username;
    char *password;
    int usernameLength;
    int passwordLength;
} UserInfo;

UserInfo *createUserInfo(int numAccounts);
void fillUserInfo(UserInfo *userInfo);
void deleteUser(UserInfo *userInfoList, int *numAccounts, int index);
void freeAllUserInfo(UserInfo *userInfoList, int numAccounts);

#endif // MEMORY_MANAGER_H
