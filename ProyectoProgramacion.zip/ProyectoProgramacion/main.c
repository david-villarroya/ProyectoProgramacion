#include <stdio.h>
#include <string.h>
#include "file_manager.h"
#include "memory_manager.h"

// Function prototypes
int authenticateUser(const char *username, const char *masterPassword, const UserInfo *userInfoList, int numAccounts);
void viewAllAccounts(const UserInfo *userInfoList, int numAccounts);
void addNewAccount(UserInfo *userInfoList, int *numAccounts);
void deleteAccount(UserInfo *userInfoList, int *numAccounts);
void saveDataToFile(const UserInfo *userInfoList, int numAccounts, const char *masterPassword);

int doesUserExist(const char *username, const UserInfo *userInfoList, int numAccounts) {
    char fileName[50];
    sprintf(fileName, "%s.txt", username);
    FILE *file = fopen(fileName, "r");
    if (file != NULL) {
        printf("User already exists");
        fclose(file);
        return 1;
    }
    file = fopen(fileName, "w");
    fprintf(file, "created");
    fclose(file);
    return 0;
}

void showInstructions() {
    printf("You are a new user, so we will explain how to use the program:\n");
    printf("This program stores user accounts encrypted with a master password.\n");
    printf("You will be asked to enter the username of the account to store and its password.\n");
    printf("Once you are done, the manager will encrypt and save the information.\n");
}

char* createNewAccount(const char *username, UserInfo *userInfoList, int *numAccounts) {
    char masterPassword[50];
    char masterPassword1[50];
    char masterPassword2[50];
    do {
        printf("Enter your master password: ");
        scanf("%s", masterPassword1);
        printf("Enter it again: ");
        scanf("%s", masterPassword2);
    } while (strcmp(masterPassword1, masterPassword2) != 0);
    strcpy(masterPassword, masterPassword1);
    return masterPassword;
}

void showMenu() {
    printf("Menu:\n");
    printf("1. View all saved accounts\n");
    printf("2. Add a new account\n");
    printf("3. Delete an existing account\n");
    printf("4. Save data and exit\n");
}

int main() {
    char username[50];
    char masterPassword[50];

    // Welcome the user
    printf("Welcome to the encrypted account manager\n");

    // Get the username from the user
    printf("Enter your username: ");
    scanf("%s", username);

    // Check if the user already exists
    if (!doesUserExist(username, NULL, 0)) {
        showInstructions();
        createNewAccount(username, NULL, 0);
    } else {
        // The user already exists, authenticate
        printf("Enter your master password: ");
        scanf("%s", masterPassword);

        if (authenticateUser(username, masterPassword, NULL, 0)) {
            // Successful authentication, load data and show menu
            UserInfo *userInfoList = NULL;
            int numAccounts = 0;

            // Here, the data would be loaded from the file
            readUserInfo("data.dat", masterPassword, &userInfoList, &numAccounts);

            showMenu();

            int choice;
            scanf("%d", &choice);

            switch (choice) {
                case 1:
                    viewAllAccounts(userInfoList, numAccounts);
                    break;
                case 2:
                    addNewAccount(userInfoList, &numAccounts);
                    break;
                case 3:
                    deleteAccount(userInfoList, &numAccounts);
                    break;
                case 4:
                    saveDataToFile(userInfoList, numAccounts, masterPassword);
                    break;
                default:
                    printf("Invalid option.\n");
                    break;
            }

            // Free memory before exiting
            freeAllUserInfo(userInfoList, numAccounts);
        } else {
            printf("Authentication failed. Exiting the program.\n");
        }
    }

    return 0;
}

