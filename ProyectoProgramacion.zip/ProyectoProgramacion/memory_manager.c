#include "memory_manager.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

UserInfo *createUserInfo(int numAccounts) {
    // Reserve memory for the UserInfo array
    UserInfo *userInfoList = (UserInfo *)malloc(numAccounts * sizeof(UserInfo));

    // Check if the memory reservation was successful
    if (userInfoList == NULL) {
        fprintf(stderr, "Error al reservar memoria para UserInfo.\n");
        exit(EXIT_FAILURE);
    }

    // Initialize the fields of each UserInfo
    for (int i = 0; i < numAccounts; ++i) {
        userInfoList[i].username = NULL;
        userInfoList[i].password = NULL;
        userInfoList[i].usernameLength = 0;
        userInfoList[i].passwordLength = 0;
    }

    return userInfoList;
}

void fillUserInfo(UserInfo *userInfo) {
    // Prompts the user to enter the username and password
    printf("Ingrese el nombre de usuario: ");
    userInfo->username = (char *)malloc(50 * sizeof(char));  // Reserva memoria para el nombre de usuario
    scanf("%s", userInfo->username);

    printf("Ingrese la contraseña: ");
    userInfo->password = (char *)malloc(50 * sizeof(char));  // Reserva memoria para la contraseña
    scanf("%s", userInfo->password);

    // Store the length of the strings
    userInfo->usernameLength = strlen(userInfo->username);
    userInfo->passwordLength = strlen(userInfo->password);

    // Frees previous memory, if it has already been allocated
    free(userInfo->username);
    free(userInfo->password);

    // Reserve memory for character strings
    userInfo->username = (char *)malloc((userInfo->usernameLength + 1) * sizeof(char));
    userInfo->password = (char *)malloc((userInfo->passwordLength + 1) * sizeof(char));

    // Check if the memory reservation was successful
    if (userInfo->username == NULL || userInfo->password == NULL) {
        fprintf(stderr, "Error al reservar memoria para cadenas de UserInfo.\n");
        exit(EXIT_FAILURE);
    }

    // Copy the data to the reserved strings
    strcpy(userInfo->username, userInfo->username);
    strcpy(userInfo->password, userInfo->password);
}

void deleteUser(UserInfo *userInfoList, int *numAccounts, int index) {
    // Check if the index is valid
    if (index >= 0 && index < *numAccounts) {
        // Libera la memoria de las cadenas de caracteres
        free(userInfoList[index].username);
        free(userInfoList[index].password);

        // Move the remaining beads up
        for (int i = index; i < *numAccounts - 1; ++i) {
            userInfoList[i] = userInfoList[i + 1];
        }

        // Update the number of accounts
        (*numAccounts)--;
    } else {
        printf("Índice no válido.\n");
    }
}

void freeAllUserInfo(UserInfo *userInfoList, int numAccounts) {
    // Free the memory of each UserInfo in the array
    for (int i = 0; i < numAccounts; ++i) {
        free(userInfoList[i].username);
        free(userInfoList[i].password);
    }

    // Free the memory of the UserInfo array
    free(userInfoList);
}