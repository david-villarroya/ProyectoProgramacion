#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

#include "memory_manager.h"

int readUserInfo(const char *path, const char *encryptionKey, UserInfo **userInfoList, int *numAccounts);
int writeUserInfo(const char *path, const UserInfo *userInfoList, int numAccounts, const char *encryptionKey);

#endif // FILE_MANAGER_H
